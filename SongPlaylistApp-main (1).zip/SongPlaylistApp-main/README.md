Basic app tutorial for better understaning of Object oriented design using Java and Java collections.
